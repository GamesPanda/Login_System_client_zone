<?php // GalaxyCode Panel v1.0 by Marek_p

session_start();

if($_SESSION["isloggedin"] > 0) {

    if($_SESSION["rank"] == "user") {

        $username = $_SESSION["username"];
        $password = $_SESSION["password"];
        $kredit = $_SESSION["kredit"];
        $rank = $_SESSION["rank"];
        $id = $_SESSION["id"];

    } else {
        header("Location: ../auth/login.php");
    }
} else {
    header("Location: ../auth/login.php");
}
?>
<!DOCTYPE html>
<html lang="cs"> <!-- Jazyk -->
<head>

    <!-- ##### Hlavičky ##### -->

    <meta charset="UTF-8"> <!-- Encoding -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"> <!-- Kompatibilita -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> <!-- Responsibilita -->
    <link rel = "icon" href="images/logo.png" type ="image/x-icon">  <!-- Ikona v Kartě Prohlížeče -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> <!-- Fa Ikony -->
    <link rel="stylesheet" href="../css/client/users.css"> <!-- Import CSS Souboru -->
    <title>GalaxyCode | Uživatelé</title> <!-- Jméno Karty v Prohlížeči -->

    <!-- ##### Konec Hlavičky ####### -->

</head>

<?php include("../includes/client/navbar.php"); ?>

  <div class="main">
    <div class="undertabs">
        <h1>Správa Uživatele</h1> <!-- Nadpis Velké Karty -->
    </div>
    <div class="settings_card">
        <h1>Upravit Jméno</h1> <!-- Upravení Jména -->
        <form action="users.php" method="post">
            <input class="center" type="text" name="username2" placeholder="🔖Nové Jméno" required><br>
            <input class="center" type="submit" name="submit2" value="Uložit"> <!-- Uložení -->
        </form>
    </div>
      <?php // ##### Upravení Jména ##### //

      if(isset($_POST["submit2"])) {

          $username2 = $_POST["username2"];

          include("../includes/client/db.php");

          $conn2 = new mysqli($db_hostname, $db_username, $db_password, $db_database);

          if ($conn2->connect_error) {
              die("[ERROR] Nepodařilo se spojit s databází! <br> " . $conn2->connect_error);
          }

          $sql2 = "UPDATE users SET username='$username2' WHERE id=$id";
          $result2 = $conn2->query($sql2);
      }
      ?>
    <div class="settings_card">
        <h1>Upravit Heslo</h1> <!-- Upravení Hesla -->
        <form action="users.php" method="post">
            <input class="center" type="password" name="password3" placeholder="🔒Nové Heslo" required><br>
            <input class="center" type="submit" name="submit3" value="Uložit"> <!-- Uložení -->
        </form>
    </div>
      <?php // ##### Upravení Hesla ##### //

      if(isset($_POST["submit3"])) {

          $password3 = $_POST["password3"];

          include("../includes/client/db.php");

          $conn3 = new mysqli($db_hostname, $db_username, $db_password, $db_database);

          if ($conn3->connect_error) {
              die("[ERROR] Nepodařilo se spojit s databází! <br> " . $conn3->connect_error);
          }

          $sql3 = "UPDATE users SET password='$password3' WHERE id=$id";
          $result3 = $conn3->query($sql3);
      }
      ?>

  <!-- ########## Konec Kart a Statistik ########## -->

  <!-- ########## Konec Body ###################### -->

</body>

<?php include("../includes/client/colors.php") ?>

  <!-- ########## Scripty ######################### -->

<script type="text/javascript" src="vanilla-tilt.js"></script>
<script>

    VanillaTilt.init(document.querySelectorAll(""),{ // .card
        max: 25,
        speed: 400
    });

</script>

  <!-- ########## Konec Scriptů ################### -->

</html>