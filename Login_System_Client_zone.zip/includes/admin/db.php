<?php // GalaxyCode Panel v1.0 by Marek_p
$db_hostname = "localhost";
$db_username = "root";
$db_password = "";
$db_database = "mareklogin";
?>
